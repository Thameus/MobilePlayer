# ControleTV

O celular vira o controle remoto e a TV mostra **só o app** (o SimplePlay), que roda no celular em segundo plano e é transmitido por **Smart View / Screen Share (Miracast)**.

Feito para: Samsung Galaxy A07 (Android 15+) + TV LG antiga com Screen Share. Funciona em qualquer Android 11+ cujo espelhamento crie uma "segunda tela".

## Como funciona

1. **Conectar TV** abre o Smart View, e você escolhe a TV.
2. O Android passa a ver a TV como uma segunda tela.
3. **Abrir na TV** abre o SimplePlay *direto na tela da TV*, e o celular continua livre.
4. O celular vira o controle:
   - **Setas:** ▲▼◀▶, OK e Voltar movem a seleção no app, como um controle de TV.
   - **Touchpad:** aparece um cursor na TV. Arraste para mover, toque para clicar e use 2 dedos para rolar.
   - Play/pause, avançar, voltar e o volume (o som sai pela TV).
5. Uma notificação fixa ("Transmitindo para a TV") mantém tudo rodando, com o botão **Parar**.

## Gerar o APK (pelo celular, sem computador)

1. Crie um repositório novo no GitHub (pode ser privado), por exemplo `ControleTV`.
2. **Add file → Upload files:** envie o arquivo `ControleTV-projeto.zip` **sem extrair** e confirme (Commit).
3. **Add file → Create new file:** no nome, digite exatamente `.github/workflows/build.yml`, cole o conteúdo do arquivo `build.yml` e confirme.
4. Abra a aba **Actions** e espere o "Gerar APK" ficar verde (uns 3 a 5 minutos).
5. O APK fica em **Releases → "ControleTV – última versão"**, com um link fixo:
   `https://github.com/SEU_USUARIO/ControleTV/releases/download/latest/ControleTV.apk`
   O link só abre sem login se o repositório for **público**. Se for privado, baixe logado no GitHub pelo celular.

Pelo computador: suba a pasta inteira do projeto (o workflow já está em `.github/workflows`).

A chave de assinatura é fixa (`keystore/`), então cada versão nova instala **por cima** da anterior.

## Primeiro uso

1. Instale o APK e abra o **ControleTV**. Permita as notificações.
2. Toque em **Ativar controle → Abrir Acessibilidade → Aplicativos instalados → ControleTV** e ligue.
   - Se aparecer **"Configuração restrita"**: *Info do app* → menu **⋮** → **Permitir configurações restritas**. Depois ligue de novo.
3. Feche o SimplePlay se ele estiver aberto no celular.
4. **1 · Conectar TV**: no Smart View, escolha a LG. Na TV, aceite a conexão.
5. **2 · Abrir na TV**: o SimplePlay aparece na TV.
6. Se algo não funcionar, toque em **Diagnóstico → Copiar** e cole na conversa.

## Modos de comando (em Ajustes)

| Modo | Como funciona | Quando usar |
|---|---|---|
| **Acessibilidade** (padrão) | Lê a tela do app na TV e move o foco, clica e volta | Funciona com qualquer app, sem mexer no código |
| **Integração** | Manda teclas reais de controle remoto para o app | Mais preciso. Exige colar `docs/IntegracaoSimplePlay.kt` no código do SimplePlay |

Em Ajustes também dá para trocar o app alvo (o padrão é `br.com.simpleplay`).

## Limites conhecidos

- **Algumas versões do Smart View só espelham** e não criam a segunda tela. O Diagnóstico mostra isso ("TV detectada: nenhuma" mesmo conectado).
- **Voltar no modo Acessibilidade:** o Android manda o "voltar" para a última tela tocada. Por isso o app dá um toque rápido num canto vazio da TV antes. Se der problema, use o modo Integração.
- **Atraso:** o Miracast tem um pequeno delay. É tranquilo para vídeo e ruim para jogos.
- **Celular simples (A07):** rodar o app e transmitir ao mesmo tempo esquenta e gasta bateria. Use **Escurecer tela** e, se puder, deixe o celular na tomada.
- **A tela do celular precisa ficar ligada**, porque alguns aparelhos cortam a transmissão quando ela apaga. O ControleTV mantém a tela acesa enquanto está aberto.

## Estrutura

```
app/src/main/java/br/com/thameus/controletv/
  MainActivity.kt                 tela do controle
  Telas.kt                        acha a TV, abre o app nela, diagnóstico
  ControleAccessibilityService.kt setas, OK, voltar, gestos e cursor na TV
  TransmissaoService.kt           segundo plano + notificação
  TouchpadView.kt / CursorView.kt touchpad e cursor
  Integracao.kt + Prefs.kt        modo integração e ajustes
docs/IntegracaoSimplePlay.kt      código opcional para o SimplePlay
.github/workflows/build.yml       gera o APK no GitHub
```
