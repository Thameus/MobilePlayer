// =====================================================================================
//  MODO INTEGRAÇÃO — cole isto no SimplePlay (opcional, mas deixa o controle perfeito)
// =====================================================================================
//
//  Sem isto, o ControleTV usa a Acessibilidade, que funciona com qualquer app mas
//  "simula" o controle. Com isto, o SimplePlay recebe as setas/OK/voltar como se
//  fosse um controle remoto de TV de verdade (o app já é feito para TV/leanback).
//
//  Como usar:
//   1. Coloque este código na Activity principal do SimplePlay (e no PlayerActivity),
//      ou numa BaseActivity que as duas herdem.
//   2. No ControleTV: Ajustes → "Integração".
//
//  Imports necessários:
//   import android.content.BroadcastReceiver
//   import android.content.Context
//   import android.content.Intent
//   import android.content.IntentFilter
//   import android.os.Build
//   import android.view.KeyEvent
//   import android.view.View
//   import android.os.SystemClock
// -------------------------------------------------------------------------------------

private val receptorControleTV = object : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val code = i.getIntExtra("keycode", -1)
        if (code >= 0) teclaDoControleTV(code)
    }
}

private fun teclaDoControleTV(code: Int) {
    // 1) Entrega a tecla para a tela, do jeito que um controle faria.
    val t = SystemClock.uptimeMillis()
    val tratou = dispatchKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0)) or
        dispatchKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_UP, code, 0))
    if (tratou) return

    // 2) Se ninguém tratou, faz a navegação de foco na mão.
    val raiz = window.decorView
    val focado: View? = raiz.findFocus()
    when (code) {
        KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN,
        KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT -> {
            val dir = when (code) {
                KeyEvent.KEYCODE_DPAD_UP -> View.FOCUS_UP
                KeyEvent.KEYCODE_DPAD_DOWN -> View.FOCUS_DOWN
                KeyEvent.KEYCODE_DPAD_LEFT -> View.FOCUS_LEFT
                else -> View.FOCUS_RIGHT
            }
            if (focado == null) raiz.requestFocus(View.FOCUS_DOWN)
            else focado.focusSearch(dir)?.requestFocusFromTouch()
        }
        KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> focado?.performClick()
        // Se a Activity for AppCompat/ComponentActivity, prefira: onBackPressedDispatcher.onBackPressed()
        KeyEvent.KEYCODE_BACK -> onBackPressed()
    }
}

override fun onResume() {
    super.onResume()
    val filtro = IntentFilter("br.com.thameus.controletv.TECLA")
    if (Build.VERSION.SDK_INT >= 33) registerReceiver(receptorControleTV, filtro, Context.RECEIVER_EXPORTED)
    else registerReceiver(receptorControleTV, filtro)
}

override fun onPause() {
    runCatching { unregisterReceiver(receptorControleTV) }
    super.onPause()
}
