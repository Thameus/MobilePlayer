package br.com.thameus.controletv

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper

/**
 * Mantém a transmissão "viva" em segundo plano e mostra a notificação fixa
 * "Transmitindo para a TV", com o botão Parar.
 */
class TransmissaoService : Service() {

    companion object {
        private const val CANAL = "transmissao"
        private const val ID = 7
        private const val ACAO_PARAR = "br.com.thameus.controletv.PARAR"

        @Volatile
        var rodando = false
            private set

        fun iniciar(ctx: Context) {
            ctx.startForegroundService(Intent(ctx, TransmissaoService::class.java))
        }

        fun parar(ctx: Context) {
            ctx.stopService(Intent(ctx, TransmissaoService::class.java))
        }
    }

    private lateinit var dm: DisplayManager

    private val ouvinte = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) = atualizar()
        override fun onDisplayRemoved(displayId: Int) = atualizar()
        override fun onDisplayChanged(displayId: Int) {}
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        dm = getSystemService(DisplayManager::class.java)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CANAL, getString(R.string.canal_nome), NotificationManager.IMPORTANCE_LOW)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACAO_PARAR) {
            ControleAccessibilityService.instancia?.removerCursor()
            stopSelf()
            return START_NOT_STICKY
        }
        startForeground(ID, montar(), ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
        if (!rodando) dm.registerDisplayListener(ouvinte, Handler(Looper.getMainLooper()))
        rodando = true
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        if (rodando) dm.unregisterDisplayListener(ouvinte)
        rodando = false
        super.onDestroy()
    }

    private fun atualizar() {
        getSystemService(NotificationManager::class.java).notify(ID, montar())
    }

    private fun montar(): Notification {
        val tv = Telas.telaDaTv(this)
        val texto = if (tv != null) "Rodando na TV (${tv.name}). Toque para abrir o controle."
        else "TV desconectada. Toque para reconectar."

        val abrir = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val parar = PendingIntent.getService(
            this, 1,
            Intent(this, TransmissaoService::class.java).setAction(ACAO_PARAR),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CANAL)
            .setSmallIcon(R.drawable.ic_stat_tv)
            .setContentTitle(getString(R.string.notif_titulo))
            .setContentText(texto)
            .setContentIntent(abrir)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "Parar", parar).build())
            .build()
    }
}
