package br.com.thameus.controletv

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityNodeInfo.AccessibilityAction
import android.view.accessibility.AccessibilityWindowInfo
import kotlin.math.max
import kotlin.math.min

/**
 * O "braço" do controle: lê a tela do app que está na TV e age nela
 * (mover foco com as setas, clicar, voltar, tocar e arrastar com o touchpad).
 */
class ControleAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instancia: ControleAccessibilityService? = null
            private set

        val ativo: Boolean get() = instancia != null
    }

    enum class Direcao { CIMA, BAIXO, ESQUERDA, DIREITA }

    private val main = Handler(Looper.getMainLooper())

    // ---------- ciclo de vida ----------

    override fun onServiceConnected() {
        super.onServiceConnected()
        instancia = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Não precisamos reagir a eventos; só agimos quando o usuário aperta algo.
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        removerCursor()
        instancia = null
        super.onDestroy()
    }

    // ---------- leitura da tela da TV ----------

    /** Raízes das janelas do app na tela [displayId], da mais de cima para a de baixo. */
    private fun raizes(displayId: Int): List<AccessibilityNodeInfo> {
        val porTela = runCatching { windowsOnAllDisplays }.getOrNull() ?: return emptyList()
        val janelas: List<AccessibilityWindowInfo> = porTela.get(displayId) ?: return emptyList()
        val apps = janelas.filter { it.type == AccessibilityWindowInfo.TYPE_APPLICATION }
        return (apps.ifEmpty { janelas }).mapNotNull { runCatching { it.root }.getOrNull() }
    }

    private fun focado(raizes: List<AccessibilityNodeInfo>): AccessibilityNodeInfo? {
        for (r in raizes) {
            val f = runCatching { r.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) }.getOrNull()
            if (f != null && f.isVisibleToUser) return f
        }
        return null
    }

    /** Todos os elementos visíveis que podem receber foco. */
    private fun focaveis(raizes: List<AccessibilityNodeInfo>): List<AccessibilityNodeInfo> {
        val saida = ArrayList<AccessibilityNodeInfo>()
        val fila = ArrayDeque<AccessibilityNodeInfo>()
        raizes.forEach { fila.add(it) }
        var visitados = 0
        while (fila.isNotEmpty() && visitados < 3000) {
            val n = fila.removeFirst()
            visitados++
            if (n.isVisibleToUser && n.isEnabled && (n.isFocusable || n.isClickable)) saida.add(n)
            for (i in 0 until n.childCount) {
                n.getChild(i)?.let { fila.add(it) }
            }
        }
        return saida
    }

    private fun limites(n: AccessibilityNodeInfo): Rect = Rect().also { n.getBoundsInScreen(it) }

    // ---------- ações das setas / OK ----------

    /** Move o foco como um direcional de controle remoto. Retorna uma mensagem curta de status. */
    fun mover(displayId: Int, direcao: Direcao, tentativa: Int = 0): String {
        val rs = raizes(displayId)
        if (rs.isEmpty()) return "Não achei o app na TV"
        val atual = focado(rs)
        if (atual == null) {
            val primeiro = primeiroFocavel(rs) ?: return "Nada para selecionar na tela"
            primeiro.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            return "Selecionado"
        }

        // 1) O próprio Android procura o vizinho na direção (como um controle real).
        val dirView = when (direcao) {
            Direcao.CIMA -> View.FOCUS_UP
            Direcao.BAIXO -> View.FOCUS_DOWN
            Direcao.ESQUERDA -> View.FOCUS_LEFT
            Direcao.DIREITA -> View.FOCUS_RIGHT
        }
        val vizinho = runCatching { atual.focusSearch(dirView) }.getOrNull()
        if (vizinho != null && vizinho != atual && vizinho.isVisibleToUser &&
            vizinho.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        ) return "ok"

        // 2) Busca geométrica: o elemento mais próximo naquela direção.
        val candidato = maisProximo(focaveis(rs), atual, direcao)
        if (candidato != null && candidato.performAction(AccessibilityNodeInfo.ACTION_FOCUS)) return "ok"

        // 3) Chegou na borda: rola a lista e tenta de novo.
        if (tentativa == 0 && rolar(atual, direcao)) {
            main.postDelayed({ mover(displayId, direcao, 1) }, 280)
            return "rolando"
        }
        return "Fim da lista"
    }

    private fun primeiroFocavel(rs: List<AccessibilityNodeInfo>): AccessibilityNodeInfo? =
        focaveis(rs).filter { it.isFocusable }.minByOrNull { val r = limites(it); r.top * 10_000 + r.left }

    private fun maisProximo(
        todos: List<AccessibilityNodeInfo>, atual: AccessibilityNodeInfo, d: Direcao
    ): AccessibilityNodeInfo? {
        val a = limites(atual)
        var melhor: AccessibilityNodeInfo? = null
        var melhorPeso = Long.MAX_VALUE
        for (n in todos) {
            if (!n.isFocusable || n == atual) continue
            val r = limites(n)
            if (r.isEmpty || r == a) continue
            val (principal, lateral) = when (d) {
                Direcao.CIMA -> (a.top - r.bottom) to sobreposicao(a.left, a.right, r.left, r.right)
                Direcao.BAIXO -> (r.top - a.bottom) to sobreposicao(a.left, a.right, r.left, r.right)
                Direcao.ESQUERDA -> (a.left - r.right) to sobreposicao(a.top, a.bottom, r.top, r.bottom)
                Direcao.DIREITA -> (r.left - a.right) to sobreposicao(a.top, a.bottom, r.top, r.bottom)
            }
            // Tem que estar do lado certo (tolerância de alguns pixels para itens colados).
            if (principal < -8) continue
            val peso = max(principal, 0).toLong() * 3 + lateral.toLong() * 2
            if (peso < melhorPeso) {
                melhorPeso = peso; melhor = n
            }
        }
        return melhor
    }

    /** 0 se os intervalos se sobrepõem; senão a distância entre eles. */
    private fun sobreposicao(a1: Int, a2: Int, b1: Int, b2: Int): Int =
        if (b2 < a1) a1 - b2 else if (b1 > a2) b1 - a2 else 0

    private fun rolar(de: AccessibilityNodeInfo, d: Direcao): Boolean {
        val acaoDirecional = when (d) {
            Direcao.CIMA -> AccessibilityAction.ACTION_SCROLL_UP
            Direcao.BAIXO -> AccessibilityAction.ACTION_SCROLL_DOWN
            Direcao.ESQUERDA -> AccessibilityAction.ACTION_SCROLL_LEFT
            Direcao.DIREITA -> AccessibilityAction.ACTION_SCROLL_RIGHT
        }
        val acaoSimples = if (d == Direcao.BAIXO || d == Direcao.DIREITA)
            AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        var n: AccessibilityNodeInfo? = de
        while (n != null) {
            if (n.actionList.any { it.id == acaoDirecional.id }) {
                if (n.performAction(acaoDirecional.id)) return true
            }
            if (n.isScrollable && n.performAction(acaoSimples)) return true
            n = n.parent
        }
        return false
    }

    /** Botão OK: clica no item selecionado. */
    fun ok(displayId: Int): String {
        val rs = raizes(displayId)
        if (rs.isEmpty()) return "Não achei o app na TV"
        val atual = focado(rs) ?: run {
            primeiroFocavel(rs)?.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            return "Selecionado"
        }
        var n: AccessibilityNodeInfo? = atual
        while (n != null) {
            if (n.isClickable && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return "ok"
            n = n.parent
        }
        // Último recurso: toque no centro do item.
        val r = limites(atual)
        tocar(displayId, r.exactCenterX(), r.exactCenterY())
        return "ok"
    }

    /** Botão Voltar na TV. */
    fun voltar(displayId: Int): String {
        val rs = raizes(displayId)
        if (rs.isEmpty()) return "Não achei o app na TV"

        // 1) Procura um botão de voltar no próprio app.
        val nomes = listOf("voltar", "navegar para cima", "navigate up", "back")
        for (n in focaveis(rs)) {
            val desc = (n.contentDescription ?: "").toString().lowercase()
            val id = (n.viewIdResourceName ?: "").lowercase()
            if (n.isClickable && (nomes.any { desc == it } || id.endsWith("/back") || id.endsWith("/btn_back") || id.endsWith("/up"))) {
                if (n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return "ok"
            }
        }

        // 2) Voltar do sistema. Ele vai para a última tela tocada, então primeiro
        //    damos um toque num canto vazio da TV para "puxar o foco" para ela.
        val ocupados = focaveis(rs).filter { it.isClickable }.map { limites(it) }
        val area = rs.map { limites(it) }.reduce { acc, r -> Rect(acc).apply { union(r) } }
        val pontos = listOf(
            area.left + 2 to area.top + 2, area.right - 3 to area.top + 2,
            area.left + 2 to area.bottom - 3, area.right - 3 to area.bottom - 3
        )
        val livre = pontos.firstOrNull { (x, y) -> ocupados.none { it.contains(x, y) } } ?: pontos[0]
        tocar(displayId, livre.first.toFloat(), livre.second.toFloat())
        main.postDelayed({ performGlobalAction(GLOBAL_ACTION_BACK) }, 150)
        return "ok"
    }

    // ---------- gestos (touchpad) ----------

    fun tocar(displayId: Int, x: Float, y: Float) {
        val p = Path().apply { moveTo(max(x, 0f), max(y, 0f)) }
        despachar(displayId, GestureDescription.StrokeDescription(p, 0, 60))
    }

    fun deslizar(displayId: Int, x1: Float, y1: Float, x2: Float, y2: Float, duracao: Long = 300) {
        val p = Path().apply { moveTo(max(x1, 0f), max(y1, 0f)); lineTo(max(x2, 0f), max(y2, 0f)) }
        despachar(displayId, GestureDescription.StrokeDescription(p, 0, duracao))
    }

    private fun despachar(displayId: Int, traco: GestureDescription.StrokeDescription) {
        val g = GestureDescription.Builder().addStroke(traco).setDisplayId(displayId).build()
        runCatching { dispatchGesture(g, null, null) }
    }

    // ---------- cursor desenhado na TV ----------

    private var cursor: View? = null
    private var cursorWm: WindowManager? = null
    private var cursorLp: WindowManager.LayoutParams? = null
    private var cursorTela = -1
    private var larguraTela = 1920
    private var alturaTela = 1080
    var cursorX = 0f; private set
    var cursorY = 0f; private set
    private val tamanhoCursor = 36

    /** Mostra o cursor no centro da TV. Retorna false se não conseguiu. */
    fun mostrarCursor(displayId: Int): Boolean {
        if (cursor != null && cursorTela == displayId) return true
        removerCursor()
        val display = getSystemService(DisplayManager::class.java).getDisplay(displayId) ?: return false
        return try {
            val ctx = createDisplayContext(display)
                .createWindowContext(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, null)
            val wm = ctx.getSystemService(WindowManager::class.java)
            val b = wm.maximumWindowMetrics.bounds
            larguraTela = b.width(); alturaTela = b.height()
            cursorX = larguraTela / 2f; cursorY = alturaTela / 2f
            val v = CursorView(ctx)
            val lp = WindowManager.LayoutParams(
                tamanhoCursor, tamanhoCursor,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = (cursorX - tamanhoCursor / 2).toInt(); y = (cursorY - tamanhoCursor / 2).toInt()
            }
            wm.addView(v, lp)
            cursor = v; cursorWm = wm; cursorLp = lp; cursorTela = displayId
            true
        } catch (e: Exception) {
            false
        }
    }

    fun moverCursor(dx: Float, dy: Float) {
        cursorX = min(max(cursorX + dx, 0f), larguraTela - 1f)
        cursorY = min(max(cursorY + dy, 0f), alturaTela - 1f)
        val lp = cursorLp ?: return
        lp.x = (cursorX - tamanhoCursor / 2).toInt()
        lp.y = (cursorY - tamanhoCursor / 2).toInt()
        runCatching { cursorWm?.updateViewLayout(cursor, lp) }
    }

    fun clicarNoCursor(displayId: Int) = tocar(displayId, cursorX, cursorY)

    /** Rola o conteúdo embaixo do cursor (dy > 0 = rolar para baixo). */
    fun rolarNoCursor(displayId: Int, dy: Float) {
        val dist = alturaTela * 0.35f * (if (dy > 0) 1 else -1)
        val y2 = min(max(cursorY - dist, 0f), alturaTela - 1f)
        deslizar(displayId, cursorX, cursorY, cursorX, y2, 250)
    }

    fun removerCursor() {
        val v = cursor ?: return
        runCatching { cursorWm?.removeView(v) }
        cursor = null; cursorWm = null; cursorLp = null; cursorTela = -1
    }
}
