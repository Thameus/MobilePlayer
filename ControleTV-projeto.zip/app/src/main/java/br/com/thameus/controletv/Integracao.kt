package br.com.thameus.controletv

import android.content.Context
import android.content.Intent
import android.view.KeyEvent

/**
 * Modo "Integração": em vez de usar a Acessibilidade, manda a tecla direto para o app alvo,
 * que a recebe como se fosse um controle remoto de verdade.
 * O app alvo precisa ter o trecho de docs/IntegracaoSimplePlay.kt.
 */
object Integracao {
    const val ACAO = "br.com.thameus.controletv.TECLA"
    const val EXTRA_TECLA = "keycode"

    fun enviar(ctx: Context, keyCode: Int) {
        val i = Intent(ACAO)
            .setPackage(Prefs.pacote(ctx))
            .putExtra(EXTRA_TECLA, keyCode)
        ctx.sendBroadcast(i)
    }

    val CIMA = KeyEvent.KEYCODE_DPAD_UP
    val BAIXO = KeyEvent.KEYCODE_DPAD_DOWN
    val ESQUERDA = KeyEvent.KEYCODE_DPAD_LEFT
    val DIREITA = KeyEvent.KEYCODE_DPAD_RIGHT
    val OK = KeyEvent.KEYCODE_DPAD_CENTER
    val VOLTAR = KeyEvent.KEYCODE_BACK
}
