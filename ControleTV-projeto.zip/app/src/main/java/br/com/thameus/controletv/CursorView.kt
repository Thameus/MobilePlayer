package br.com.thameus.controletv

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

/** Bolinha branca com borda escura: o "mouse" que aparece na TV no modo touchpad. */
class CursorView(ctx: Context) : View(ctx) {
    private val borda = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(200, 0, 0, 0) }
    private val miolo = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }

    override fun onDraw(canvas: Canvas) {
        val c = width / 2f
        canvas.drawCircle(c, c, c, borda)
        canvas.drawCircle(c, c, c * 0.68f, miolo)
    }
}
