package br.com.thameus.controletv

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.display.DisplayManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import br.com.thameus.controletv.ControleAccessibilityService.Direcao

class MainActivity : Activity() {

    private lateinit var txtStatus: TextView
    private lateinit var txtLog: TextView
    private lateinit var painelSetas: View
    private lateinit var painelTouch: View
    private lateinit var btnModoSetas: Button
    private lateinit var btnModoTouch: Button
    private lateinit var btnEscurecer: Button

    private val main = Handler(Looper.getMainLooper())
    private lateinit var dm: DisplayManager
    private lateinit var audio: AudioManager
    private var modoTouch = false
    private var escurecida = false

    private val ouvinteTelas = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) = atualizarStatus()
        override fun onDisplayRemoved(displayId: Int) {
            if (Telas.telaDaTv(this@MainActivity) == null) servico()?.removerCursor()
            atualizarStatus()
        }
        override fun onDisplayChanged(displayId: Int) = atualizarStatus()
    }

    // ---------------------------------------------------------------- ciclo de vida

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        dm = getSystemService(DisplayManager::class.java)
        audio = getSystemService(AudioManager::class.java)

        txtStatus = findViewById(R.id.txtStatus)
        txtLog = findViewById(R.id.txtLog)
        painelSetas = findViewById(R.id.painelSetas)
        painelTouch = findViewById(R.id.painelTouch)
        btnModoSetas = findViewById(R.id.btnModoSetas)
        btnModoTouch = findViewById(R.id.btnModoTouch)
        btnEscurecer = findViewById(R.id.btnEscurecer)

        // Conexão
        clique(R.id.btnConectar) {
            if (Telas.abrirMenuDeTransmissao(this)) log("Escolha a TV LG na lista e volte para cá.")
            else log("Abra o Smart View pelo painel rápido (puxe a barra de cima) e escolha a TV.")
        }
        clique(R.id.btnAbrir) { abrirNaTv() }
        clique(R.id.btnInicio) { abrirNaTv() }
        clique(R.id.btnAcessibilidade) { dialogoAcessibilidade() }
        clique(R.id.btnDiag) { dialogoDiagnostico() }
        clique(R.id.btnConfig) { dialogoAjustes() }

        // Abas
        clique(R.id.btnModoSetas) { trocarModo(false) }
        clique(R.id.btnModoTouch) { trocarModo(true) }

        // Setas (segurar = repetir)
        repetir(R.id.btnCima) { seta(Direcao.CIMA) }
        repetir(R.id.btnBaixo) { seta(Direcao.BAIXO) }
        repetir(R.id.btnEsquerda) { seta(Direcao.ESQUERDA) }
        repetir(R.id.btnDireita) { seta(Direcao.DIREITA) }
        clique(R.id.btnOk) { okTv() }
        clique(R.id.btnVoltar) { voltarTv() }

        // Touchpad
        findViewById<TouchpadView>(R.id.touchpad).ouvinte = object : TouchpadView.Ouvinte {
            override fun aoMover(dx: Float, dy: Float) {
                servico()?.moverCursor(dx, dy)
            }
            override fun aoClicar() {
                comTv { tv -> servicoOuAviso()?.clicarNoCursor(tv) }
            }
            override fun aoRolar(dy: Float) {
                comTv { tv -> servicoOuAviso()?.rolarNoCursor(tv, dy) }
            }
        }
        clique(R.id.btnRolarCima) { comTv { tv -> servicoOuAviso()?.rolarNoCursor(tv, -1f) } }
        clique(R.id.btnRolarBaixo) { comTv { tv -> servicoOuAviso()?.rolarNoCursor(tv, 1f) } }

        // Mídia e volume
        clique(R.id.btnPlay) { midia(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) }
        repetir(R.id.btnRetroceder) { midia(KeyEvent.KEYCODE_MEDIA_REWIND) }
        repetir(R.id.btnAvancar) { midia(KeyEvent.KEYCODE_MEDIA_FAST_FORWARD) }
        repetir(R.id.btnVolMenos) { volume(AudioManager.ADJUST_LOWER) }
        repetir(R.id.btnVolMais) { volume(AudioManager.ADJUST_RAISE) }
        clique(R.id.btnMudo) { volume(AudioManager.ADJUST_TOGGLE_MUTE) }

        // Energia
        clique(R.id.btnEscurecer) { alternarEscurecer() }
        clique(R.id.btnParar) {
            servico()?.removerCursor()
            TransmissaoService.parar(this)
            log("Transmissão parada. Para desligar a TV de vez, toque em Smart View → Desconectar.")
            atualizarStatus()
        }

        trocarModo(false)
        pedirNotificacoes()
    }

    override fun onStart() {
        super.onStart()
        dm.registerDisplayListener(ouvinteTelas, main)
    }

    override fun onResume() {
        super.onResume()
        atualizarStatus()
    }

    override fun onStop() {
        dm.unregisterDisplayListener(ouvinteTelas)
        super.onStop()
    }

    // ---------------------------------------------------------------- ações

    private fun abrirNaTv() {
        when (val r = Telas.abrirNaTv(this)) {
            is Telas.Resultado.Ok -> {
                TransmissaoService.iniciar(this)
                log("Abrindo ${Prefs.pacote(this)} na TV…")
                if (modoTouch) main.postDelayed({ mostrarCursor() }, 800)
            }
            is Telas.Resultado.Erro -> log(r.mensagem)
        }
        atualizarStatus()
    }

    private fun seta(d: Direcao) = comTv { tv ->
        if (Prefs.modo(this) == Prefs.Modo.INTEGRACAO) {
            Integracao.enviar(this, when (d) {
                Direcao.CIMA -> Integracao.CIMA
                Direcao.BAIXO -> Integracao.BAIXO
                Direcao.ESQUERDA -> Integracao.ESQUERDA
                Direcao.DIREITA -> Integracao.DIREITA
            })
        } else {
            servicoOuAviso()?.let { s -> mostrarResultado(s.mover(tv, d)) }
        }
    }

    private fun okTv() = comTv { tv ->
        if (Prefs.modo(this) == Prefs.Modo.INTEGRACAO) Integracao.enviar(this, Integracao.OK)
        else servicoOuAviso()?.let { s -> mostrarResultado(s.ok(tv)) }
    }

    private fun voltarTv() = comTv { tv ->
        if (Prefs.modo(this) == Prefs.Modo.INTEGRACAO) Integracao.enviar(this, Integracao.VOLTAR)
        else servicoOuAviso()?.let { s -> mostrarResultado(s.voltar(tv)) }
    }

    private fun midia(codigo: Int) {
        if (Prefs.modo(this) == Prefs.Modo.INTEGRACAO) {
            Integracao.enviar(this, codigo)
        } else {
            // Funciona com players que usam MediaSession (ExoPlayer/Media3 normalmente usam).
            audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, codigo))
            audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, codigo))
        }
    }

    private fun volume(direcao: Int) {
        audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, direcao, AudioManager.FLAG_SHOW_UI)
    }

    private fun trocarModo(touch: Boolean) {
        modoTouch = touch
        painelTouch.visibility = if (touch) View.VISIBLE else View.GONE
        painelSetas.visibility = if (touch) View.GONE else View.VISIBLE
        btnModoTouch.setBackgroundResource(if (touch) R.drawable.botao_destaque else R.drawable.botao)
        btnModoSetas.setBackgroundResource(if (touch) R.drawable.botao else R.drawable.botao_destaque)
        if (touch) mostrarCursor() else servico()?.removerCursor()
    }

    private fun mostrarCursor() {
        val tv = Telas.telaDaTv(this) ?: return
        val s = servico() ?: return
        if (!s.mostrarCursor(tv.displayId)) log("Não consegui desenhar o cursor na TV (o toque ainda funciona).")
    }

    private fun alternarEscurecer() {
        escurecida = !escurecida
        val lp = window.attributes
        lp.screenBrightness = if (escurecida) 0.01f else WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
        window.attributes = lp
        btnEscurecer.text = if (escurecida) "Clarear tela" else "Escurecer tela"
    }

    // ---------------------------------------------------------------- auxiliares

    private fun servico(): ControleAccessibilityService? = ControleAccessibilityService.instancia

    private fun servicoOuAviso(): ControleAccessibilityService? {
        val s = servico()
        if (s == null) dialogoAcessibilidade()
        return s
    }

    private fun comTv(acao: (Int) -> Unit) {
        val tv = Telas.telaDaTv(this)
        if (tv == null) {
            log("Nenhuma TV conectada. Toque em \"1 · Conectar TV\".")
            return
        }
        acao(tv.displayId)
    }

    private fun mostrarResultado(msg: String) {
        if (msg != "ok" && msg != "rolando") log(msg)
    }

    private fun log(msg: String) {
        txtLog.text = msg
    }

    private fun atualizarStatus() {
        val tv = Telas.telaDaTv(this)
        val pacote = Prefs.pacote(this)
        val instalado = Telas.intentDoApp(this, pacote) != null
        val modo = Prefs.modo(this)
        val linhas = listOf(
            if (tv != null) "📺 TV: ✅ conectada — ${tv.name}" else "📺 TV: ❌ não conectada",
            if (ControleAccessibilityService.ativo) "🎮 Controle: ✅ ativo"
            else "🎮 Controle: ❌ desativado — toque em \"Ativar controle\"",
            "📦 App: $pacote ${if (instalado) "✅" else "❌ não instalado"}",
            "⚙️ Modo: " + if (modo == Prefs.Modo.INTEGRACAO) "Integração" else "Acessibilidade",
            if (TransmissaoService.rodando) "🔔 Segundo plano: ligado" else "🔔 Segundo plano: desligado"
        )
        txtStatus.text = linhas.joinToString("\n")
    }

    private fun clique(id: Int, acao: () -> Unit) {
        findViewById<View>(id).setOnClickListener { v ->
            v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            acao()
        }
    }

    /** Executa ao tocar e repete enquanto o dedo estiver segurando. */
    @SuppressLint("ClickableViewAccessibility")
    private fun repetir(id: Int, acao: () -> Unit) {
        val v = findViewById<View>(id)
        val repetidor = object : Runnable {
            override fun run() {
                acao()
                main.postDelayed(this, 160)
            }
        }
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.isPressed = true
                    view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                    acao()
                    main.postDelayed(repetidor, 450)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    view.isPressed = false
                    main.removeCallbacks(repetidor)
                }
            }
            true
        }
    }

    private fun pedirNotificacoes() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    // ---------------------------------------------------------------- diálogos

    private fun dialogoAcessibilidade() {
        AlertDialog.Builder(this)
            .setTitle("Ativar o controle")
            .setMessage(
                "Para o celular controlar o app na TV, ative o serviço do ControleTV:\n\n" +
                    "1. Toque em \"Abrir Acessibilidade\".\n" +
                    "2. Vá em \"Aplicativos instalados\" → \"ControleTV\" e ligue.\n\n" +
                    "Se aparecer \"Configuração restrita\" (acontece com app instalado por APK):\n" +
                    "• Toque em \"Info do app\" → menu ⋮ no canto → \"Permitir configurações restritas\".\n" +
                    "• Depois volte e ligue de novo."
            )
            .setPositiveButton("Abrir Acessibilidade") { _, _ ->
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            .setNeutralButton("Info do app") { _, _ ->
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                )
            }
            .setNegativeButton("Fechar", null)
            .show()
    }

    private fun dialogoDiagnostico() {
        val texto = Telas.diagnostico(this) +
            "\nControle (acessibilidade): " + (if (ControleAccessibilityService.ativo) "ativo" else "desativado") +
            "\nAndroid ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}) — ${Build.MANUFACTURER} ${Build.MODEL}"
        AlertDialog.Builder(this)
            .setTitle("Diagnóstico")
            .setMessage(texto)
            .setPositiveButton("Copiar") { _, _ ->
                getSystemService(ClipboardManager::class.java)
                    .setPrimaryClip(ClipData.newPlainText("diagnostico", texto))
                log("Diagnóstico copiado. Cole na conversa para análise.")
            }
            .setNegativeButton("Fechar", null)
            .show()
    }

    private fun dialogoAjustes() {
        val pad = (16 * resources.displayMetrics.density).toInt()
        val caixa = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad / 2, pad, 0)
        }
        caixa.addView(TextView(this).apply { text = "Pacote do app para abrir na TV:" })
        val campo = EditText(this).apply {
            setText(Prefs.pacote(this@MainActivity))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            isSingleLine = true
        }
        caixa.addView(campo)
        caixa.addView(TextView(this).apply {
            text = "\nComo mandar os comandos:"
        })
        val grupo = RadioGroup(this)
        val rAcess = RadioButton(this).apply { id = View.generateViewId(); text = "Acessibilidade (funciona com qualquer app)" }
        val rInteg = RadioButton(this).apply { id = View.generateViewId(); text = "Integração (o app tem o código do ControleTV — teclas reais)" }
        grupo.addView(rAcess); grupo.addView(rInteg)
        grupo.check(if (Prefs.modo(this) == Prefs.Modo.INTEGRACAO) rInteg.id else rAcess.id)
        caixa.addView(grupo)

        AlertDialog.Builder(this)
            .setTitle("Ajustes")
            .setView(caixa)
            .setPositiveButton("Salvar") { _, _ ->
                Prefs.salvarPacote(this, campo.text.toString())
                Prefs.salvarModo(this, if (grupo.checkedRadioButtonId == rInteg.id) Prefs.Modo.INTEGRACAO else Prefs.Modo.ACESSIBILIDADE)
                atualizarStatus()
                log("Ajustes salvos.")
            }
            .setNeutralButton("Padrão") { _, _ ->
                Prefs.salvarPacote(this, Prefs.PACOTE_PADRAO)
                Prefs.salvarModo(this, Prefs.Modo.ACESSIBILIDADE)
                atualizarStatus()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}
