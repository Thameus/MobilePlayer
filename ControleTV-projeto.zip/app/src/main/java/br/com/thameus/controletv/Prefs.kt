package br.com.thameus.controletv

import android.content.Context

/** Configurações simples salvas no aparelho. */
object Prefs {
    private const val ARQUIVO = "controletv"
    private const val K_PACOTE = "pacote_alvo"
    private const val K_MODO = "modo_comando"

    const val PACOTE_PADRAO = "br.com.simpleplay"

    /** ACESSIBILIDADE = funciona com qualquer app. INTEGRACAO = o app alvo recebe teclas reais (ver docs). */
    enum class Modo { ACESSIBILIDADE, INTEGRACAO }

    fun pacote(ctx: Context): String =
        ctx.getSharedPreferences(ARQUIVO, Context.MODE_PRIVATE)
            .getString(K_PACOTE, PACOTE_PADRAO)?.trim().takeUnless { it.isNullOrEmpty() } ?: PACOTE_PADRAO

    fun salvarPacote(ctx: Context, pacote: String) {
        ctx.getSharedPreferences(ARQUIVO, Context.MODE_PRIVATE).edit()
            .putString(K_PACOTE, pacote.trim()).apply()
    }

    fun modo(ctx: Context): Modo {
        val v = ctx.getSharedPreferences(ARQUIVO, Context.MODE_PRIVATE).getString(K_MODO, Modo.ACESSIBILIDADE.name)
        return runCatching { Modo.valueOf(v!!) }.getOrDefault(Modo.ACESSIBILIDADE)
    }

    fun salvarModo(ctx: Context, modo: Modo) {
        ctx.getSharedPreferences(ARQUIVO, Context.MODE_PRIVATE).edit()
            .putString(K_MODO, modo.name).apply()
    }
}
