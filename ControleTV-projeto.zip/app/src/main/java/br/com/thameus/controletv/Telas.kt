package br.com.thameus.controletv

import android.app.ActivityManager
import android.app.ActivityOptions
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.hardware.display.DisplayManager
import android.provider.Settings
import android.view.Display

/** Tudo que envolve encontrar a TV (segunda tela) e abrir apps nela. */
object Telas {

    /** Primeira tela externa (Miracast/Smart View, HDMI, etc.), ou null se não houver. */
    fun telaDaTv(ctx: Context): Display? {
        val dm = ctx.getSystemService(DisplayManager::class.java)
        val apresentacao = dm.getDisplays(DisplayManager.DISPLAY_CATEGORY_PRESENTATION)
            .firstOrNull { it.displayId != Display.DEFAULT_DISPLAY && it.state != Display.STATE_OFF }
        if (apresentacao != null) return apresentacao
        // Algumas fabricantes não marcam a tela como "presentation": aceita qualquer externa.
        return dm.displays.firstOrNull { it.displayId != Display.DEFAULT_DISPLAY && it.state != Display.STATE_OFF }
    }

    /** Texto de diagnóstico com todas as telas que o Android enxerga. */
    fun diagnostico(ctx: Context): String {
        val dm = ctx.getSystemService(DisplayManager::class.java)
        val apresentacao = dm.getDisplays(DisplayManager.DISPLAY_CATEGORY_PRESENTATION).map { it.displayId }.toSet()
        val sb = StringBuilder()
        for (d in dm.displays) {
            val modo = d.mode
            sb.append("• Tela ${d.displayId}: \"${d.name}\"\n")
            sb.append("   ${modo.physicalWidth}x${modo.physicalHeight} @ ${"%.0f".format(modo.refreshRate)}Hz")
            sb.append(" | estado=${estado(d.state)}")
            sb.append(" | apresentação=${if (d.displayId in apresentacao) "sim" else "não"}")
            sb.append(" | privada=${if ((d.flags and Display.FLAG_PRIVATE) != 0) "sim" else "não"}\n")
        }
        val tv = telaDaTv(ctx)
        sb.append("\nTV detectada: ").append(tv?.let { "tela ${it.displayId} (${it.name})" } ?: "nenhuma")
        if (tv != null) {
            val intent = intentDoApp(ctx, Prefs.pacote(ctx))
            if (intent == null) {
                sb.append("\nApp alvo (${Prefs.pacote(ctx)}): não instalado")
            } else {
                val am = ctx.getSystemService(ActivityManager::class.java)
                val ok = runCatching { am.isActivityStartAllowedOnDisplay(ctx, tv.displayId, intent) }.getOrDefault(false)
                sb.append("\nPode abrir o app na TV: ").append(if (ok) "SIM ✅" else "NÃO ❌")
            }
        }
        return sb.toString()
    }

    private fun estado(s: Int) = when (s) {
        Display.STATE_ON -> "ligada"
        Display.STATE_OFF -> "desligada"
        Display.STATE_DOZE, Display.STATE_DOZE_SUSPEND -> "repouso"
        else -> "?"
    }

    /** Intent para abrir o app alvo. Prefere a versão de TV (leanback), que combina com a tela grande. */
    fun intentDoApp(ctx: Context, pacote: String): Intent? {
        val pm = ctx.packageManager
        return pm.getLeanbackLaunchIntentForPackage(pacote) ?: pm.getLaunchIntentForPackage(pacote)
    }

    sealed class Resultado {
        object Ok : Resultado()
        data class Erro(val mensagem: String) : Resultado()
    }

    /** Abre o app alvo direto na tela da TV. */
    fun abrirNaTv(ctx: Context): Resultado {
        val tv = telaDaTv(ctx) ?: return Resultado.Erro("Nenhuma TV conectada. Toque em \"Conectar TV\" primeiro.")
        val pacote = Prefs.pacote(ctx)
        val intent = intentDoApp(ctx, pacote)
            ?: return Resultado.Erro("O app $pacote não está instalado neste celular.")

        // NEW_TASK + MULTIPLE_TASK: cria uma tarefa nova na TV em vez de puxar a tarefa do celular.
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_MULTIPLE_TASK)

        val am = ctx.getSystemService(ActivityManager::class.java)
        val permitido = runCatching { am.isActivityStartAllowedOnDisplay(ctx, tv.displayId, intent) }.getOrDefault(true)
        if (!permitido) {
            return Resultado.Erro("O Android não deixou abrir o app nesta tela (tela ${tv.displayId}). Veja o Diagnóstico.")
        }

        val opcoes = ActivityOptions.makeBasic().setLaunchDisplayId(tv.displayId)
        return try {
            ctx.startActivity(intent, opcoes.toBundle())
            Resultado.Ok
        } catch (e: Exception) {
            Resultado.Erro("Falhou ao abrir na TV: ${e.message}")
        }
    }

    /** Abre o menu de transmissão (Smart View no Samsung; "Transmitir" nos outros). */
    fun abrirMenuDeTransmissao(ctx: Context): Boolean {
        val tentativas = mutableListOf<Intent>()
        ctx.packageManager.getLaunchIntentForPackage("com.samsung.android.smartmirroring")?.let { tentativas += it }
        tentativas += Intent().setComponent(
            ComponentName("com.samsung.android.smartmirroring", "com.samsung.android.smartmirroring.CaptureActivity")
        )
        tentativas += Intent(Settings.ACTION_CAST_SETTINGS)
        tentativas += Intent("android.settings.WIFI_DISPLAY_SETTINGS")
        for (i in tentativas) {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                ctx.startActivity(i)
                return true
            } catch (e: Exception) {
            }
        }
        return false
    }
}
