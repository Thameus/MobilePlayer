package br.com.thameus.controletv

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.hypot

/**
 * Área de touchpad: 1 dedo arrastando move o cursor na TV,
 * toque rápido = clique, 2 dedos arrastando para cima/baixo = rolar.
 */
class TouchpadView @JvmOverloads constructor(
    ctx: Context, attrs: AttributeSet? = null
) : View(ctx, attrs) {

    interface Ouvinte {
        fun aoMover(dx: Float, dy: Float)
        fun aoClicar()
        fun aoRolar(dy: Float)
    }

    var ouvinte: Ouvinte? = null
    var sensibilidade = 2.2f

    private val fundo = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#1E2630") }
    private val texto = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#7D8A99"); textAlign = Paint.Align.CENTER; textSize = 38f
    }
    private val caixa = RectF()

    private var ultX = 0f
    private var ultY = 0f
    private var inicioX = 0f
    private var inicioY = 0f
    private var inicioT = 0L
    private var andou = 0f
    private var doisDedos = false
    private var inicioDoisY = 0f

    override fun onDraw(canvas: Canvas) {
        caixa.set(0f, 0f, width.toFloat(), height.toFloat())
        canvas.drawRoundRect(caixa, 40f, 40f, fundo)
        canvas.drawText("Arraste para mover • toque para clicar", width / 2f, height / 2f - 12, texto)
        canvas.drawText("2 dedos para rolar", width / 2f, height / 2f + 40, texto)
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                ultX = e.x; ultY = e.y; inicioX = e.x; inicioY = e.y
                inicioT = e.eventTime; andou = 0f; doisDedos = false
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                if (e.pointerCount == 2) {
                    doisDedos = true
                    inicioDoisY = (e.getY(0) + e.getY(1)) / 2f
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (doisDedos && e.pointerCount >= 2) {
                    val y = (e.getY(0) + e.getY(1)) / 2f
                    val d = inicioDoisY - y
                    if (abs(d) > 120) {
                        ouvinte?.aoRolar(d)   // dedos subindo = rolar para baixo
                        inicioDoisY = y
                    }
                } else if (!doisDedos) {
                    val dx = e.x - ultX
                    val dy = e.y - ultY
                    ultX = e.x; ultY = e.y
                    andou += hypot(dx, dy)
                    ouvinte?.aoMover(dx * sensibilidade, dy * sensibilidade)
                }
            }
            MotionEvent.ACTION_UP -> {
                val rapido = e.eventTime - inicioT < 250
                if (!doisDedos && rapido && andou < 25) {
                    performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
                    ouvinte?.aoClicar()
                }
            }
        }
        return true
    }
}
