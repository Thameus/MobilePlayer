plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "br.com.thameus.controletv"
    compileSdk = 35

    defaultConfig {
        applicationId = "br.com.thameus.controletv"
        minSdk = 30          // Android 11+: gestos e janelas por tela (multi-display)
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    // Chave fixa: assim cada APK novo instala por cima do anterior, sem desinstalar.
    signingConfigs {
        create("fixa") {
            storeFile = rootProject.file("keystore/controletv.jks")
            storePassword = "controletv"
            keyAlias = "controletv"
            keyPassword = "controletv"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("fixa")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("fixa")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

// Sem dependências externas: só o SDK do Android.
